
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php
// Safe defaults for package fields used in the view
$package['rate_per_tourist'] = isset($package['rate_per_tourist']) && $package['rate_per_tourist'] !== null
    ? (float)$package['rate_per_tourist']
    : 0.00;

$package['max_tourists'] = $package['max_tourists'] ?? 1;
$package['date_from'] = $package['date_from'] ?? date('Y-m-d');
$package['date_to'] = $package['date_to'] ?? date('Y-m-d');
$package['description'] = $package['description'] ?? '';
$package['details'] = $package['details'] ?? '';
$package['image'] = $package['image'] ?? '';
?>
<div class="row">
  <div class="col-lg-8">
    <div class="card shadow-sm mb-4">
      <div class="card-body">
        <h4 class="card-title mb-3">
          <i class="fa fa-box me-2 text-primary"></i> <?= esc($package['title']) ?>
        </h4>

        <div class="row mb-4">
          <div class="col-md-4">
            <?php if (!empty($package['image'])): ?>
              <img src="<?= base_url('writable/uploads/'.esc($package['image'])) ?>" class="img-fluid rounded" style="object-fit:cover;height:250px;width:100%;" alt="<?= esc($package['title']) ?>">
            <?php else: ?>
              <div class="bg-light rounded d-flex align-items-center justify-content-center" style="height:250px;">
                <i class="fa fa-image fa-3x text-muted"></i>
              </div>
            <?php endif; ?>
          </div>
          <div class="col-md-8">
            <table class="table table-borderless small">
              <tr>
                <td><strong>Type:</strong></td>
                <td><span class="badge bg-<?= ($package['type'] ?? 'joiner') === 'joiner' ? 'info' : 'warning' ?>"><?= ucfirst(esc($package['type'] ?? 'joiner')) ?></span></td>
              </tr>
              <tr>
                <td><strong>Date:</strong></td>
                <td><?= date('M d, Y', strtotime($package['date_from'])) ?> - <?= date('M d, Y', strtotime($package['date_to'])) ?></td>
              </tr>
              <tr>
                <td><strong>Price per Tourist:</strong></td>
                <td>
                  <strong>₱<?= number_format($package['rate_per_tourist'], 2) ?></strong>
                </td>
              </tr>
              <tr>
                <td><strong>Max Capacity:</strong></td>
                <td><?= esc($package['max_tourists']) ?> tourists</td>
              </tr>
            </table>

            <div class="mt-3">
              <h6>Description</h6>
              <p class="text-muted"><?= esc($package['description']) ?></p>
            </div>

            <?php if (!empty($package['details'])): ?>
              <div class="mt-3">
                <h6>Package Details</h6>
                <p class="text-muted small"><?= esc($package['details']) ?></p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Booking Form -->
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title mb-3">Complete Your Booking</h5>

        <?php if (session()->getFlashdata('error')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fa fa-exclamation-circle me-2"></i> <?= session()->getFlashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        <?php endif; ?>

        <form method="post" action="<?= site_url('bookings/store') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="package_id" value="<?= esc($package['id']) ?>">

          <div class="mb-3">
            <label class="form-label">Price per Tourist</label>
            <div>
              <span class="fw-bold">₱<span id="pricePerTourist"><?= number_format($package['rate_per_tourist'], 2, '.', '') ?></span></span>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Number of Tourists</label>
            <input class="form-control" id="number_of_tourists" type="number" name="number_of_tourists" min="1" max="<?= esc($package['max_tourists']) ?>" required value="<?= esc(old('number_of_tourists', 1)) ?>">
            <small class="text-muted">Max: <?= esc($package['max_tourists']) ?> tourists</small>
          </div>

          <div class="mb-3">
            <label class="form-label">Contact Name</label>
            <input class="form-control" type="text" name="contact_name" required value="<?= esc(old('contact_name', session()->get('name'))) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Contact Email</label>
            <input class="form-control" type="email" name="contact_email" required value="<?= esc(old('contact_email', session()->get('email'))) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Contact Phone</label>
            <input class="form-control" type="text" name="contact_phone" required value="<?= esc(old('contact_phone')) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Special Requests (Optional)</label>
            <textarea class="form-control" name="special_requests" rows="3"><?= esc(old('special_requests')) ?></textarea>
          </div>

          <div class="alert alert-info">
            <strong>Estimated Total:</strong> ₱<span id="totalPrice">0.00</span>
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-success btn-lg">
              <i class="fa fa-check me-1"></i> Confirm Booking
            </button>
            <a href="<?= site_url('packages') ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
/* Get rate_per_tourist from database (admin-inputted price) */
const ratePerTourist = <?= json_encode((float)$package['rate_per_tourist']) ?>;
const touristsInput = document.getElementById('number_of_tourists');
const totalPriceSpan = document.getElementById('totalPrice');

/* Update total when number of tourists changes */
function updateTotal() {
  const tourists = Math.max(1, parseInt(touristsInput.value) || 1);
  const total = tourists * ratePerTourist;
  totalPriceSpan.textContent = total.toFixed(2);
}

/* Attach event listeners */
if (touristsInput) {
  touristsInput.addEventListener('input', updateTotal);
  touristsInput.addEventListener('change', updateTotal);
  updateTotal();
}
</script>

<?= $this->endSection() ?>