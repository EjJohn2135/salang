
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<style>
  .header-section {
    background: linear-gradient(135deg, #0066cc 0%, #00a8e8 100%);
    color: white;
    padding: 2rem;
    border-radius: 1rem;
    margin-bottom: 2rem;
  }

  .header-section h2 {
    color: white;
    margin-bottom: 0.5rem;
  }

  .table thead th {
    background: linear-gradient(135deg, #0066cc 0%, #00a8e8 100%);
    color: white;
    border: none;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
  }

  .table tbody tr:hover {
    background: #f0f9ff;
  }

  .btn-group-sm .btn {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
  }

  .empty-state {
    text-align: center;
    padding: 3rem;
    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    border-radius: 1rem;
    border: 2px dashed #00a8e8;
  }
</style>

<div class="header-section">
  <div class="d-flex justify-content-between align-items-center">
    <div>
      <h2 class="mb-1">
        <i class="fas fa-hotel me-2"></i>Accommodations
      </h2>
      <p class="mb-0" style="opacity: 0.95;">Manage hotel and resort accommodations</p>
    </div>
    <a href="<?= base_url('accommodations/create') ?>" class="btn btn-success btn-lg">
      <i class="fas fa-plus me-1"></i> Add Accommodation
    </a>
  </div>
</div>

<?php if (session()->getFlashdata('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i> <?= session()->getFlashdata('success') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i> <?= session()->getFlashdata('error') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (empty($accommodations)): ?>
  <div class="empty-state">
    <i class="fas fa-inbox" style="font-size: 3rem; color: #00a8e8; margin-bottom: 1rem;"></i>
    <h5 class="text-muted">No Accommodations Yet</h5>
    <p class="text-muted">Start by adding your first accommodation</p>
    <a href="<?= base_url('accommodations/create') ?>" class="btn btn-primary mt-3">
      <i class="fas fa-plus me-1"></i> Add Accommodation
    </a>
  </div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr>
          <th width="25%">Name</th>
          <th width="20%">Location</th>
          <th width="15%">Price/Night</th>
          <th width="30%">Description</th>
          <th width="10%">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($accommodations as $acc): ?>
          <tr>
            <td>
              <strong><?= esc($acc['name']) ?></strong>
            </td>
            <td>
              <i class="fas fa-location-dot me-1" style="color: #0066cc;"></i>
              <?= esc($acc['location']) ?>
            </td>
            <td>
              <span class="badge bg-success">₱<?= number_format($acc['price_per_night'], 2) ?></span>
            </td>
            <td>
              <small class="text-muted">
                <?= esc(strlen($acc['description']) > 50 ? substr($acc['description'], 0, 50) . '...' : $acc['description']) ?>
              </small>
            </td>
            <td>
              <div class="btn-group btn-group-sm" role="group">
                <a href="<?= base_url('accommodations/edit/'.$acc['id']) ?>" class="btn btn-warning" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <button type="button" class="btn btn-danger" onclick="deleteItem('<?= $acc['id'] ?>', 'accommodations', '<?= esc($acc['name']) ?>')" title="Delete">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<script>
const baseUrl = '<?= base_url() ?>';

function deleteItem(id, type, name) {
  Swal.fire({
    title: 'Delete Accommodation?',
    text: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6b7280',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel',
    background: '#fff'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = baseUrl + type + '/delete/' + id;
    }
  });
}
</script>

<?= $this->endSection() ?>