
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<style>
  .header-section {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    padding: 2rem;
    border-radius: 1rem;
    margin-bottom: 2rem;
  }

  .header-section h2 {
    color: white;
    margin-bottom: 0.5rem;
  }

  .table thead th {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    border: none;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
  }

  .table tbody tr:hover {
    background: #f0fdf4;
  }

  .btn-group-sm .btn {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
  }

  .empty-state {
    text-align: center;
    padding: 3rem;
    background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
    border-radius: 1rem;
    border: 2px dashed #10b981;
  }
</style>

<div class="header-section">
  <div class="d-flex justify-content-between align-items-center">
    <div>
      <h2 class="mb-1">
        <i class="fas fa-briefcase me-2"></i>Tour Agencies
      </h2>
      <p class="mb-0" style="opacity: 0.95;">Manage tour agencies and partners</p>
    </div>
    <a href="<?= base_url('touragencies/create') ?>" class="btn btn-light btn-lg text-success fw-bold">
      <i class="fas fa-plus me-1"></i> Add Tour Agency
    </a>
  </div>
</div>

<?php if (session()->getFlashdata('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i> <?= session()->getFlashdata('success') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i> <?= session()->getFlashdata('error') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (empty($agencies)): ?>
  <div class="empty-state">
    <i class="fas fa-building" style="font-size: 3rem; color: #10b981; margin-bottom: 1rem;"></i>
    <h5 class="text-success">No Tour Agencies Yet</h5>
    <p class="text-muted">Start by adding your first tour agency</p>
    <a href="<?= base_url('touragencies/create') ?>" class="btn btn-success mt-3">
      <i class="fas fa-plus me-1"></i> Add Tour Agency
    </a>
  </div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr>
          <th width="25%">Name</th>
          <th width="20%">Contact</th>
          <th width="25%">Email</th>
          <th width="20%">Address</th>
          <th width="10%">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($agencies as $agency): ?>
          <tr>
            <td>
              <strong><?= esc($agency['name']) ?></strong>
            </td>
            <td>
              <small>
                <i class="fas fa-phone me-1" style="color: #10b981;"></i>
                <?= esc($agency['contact']) ?>
              </small>
            </td>
            <td>
              <small>
                <i class="fas fa-envelope me-1" style="color: #10b981;"></i>
                <?= esc($agency['email']) ?>
              </small>
            </td>
            <td>
              <small class="text-muted">
                <?= esc(strlen($agency['address']) > 30 ? substr($agency['address'], 0, 30) . '...' : $agency['address']) ?>
              </small>
            </td>
            <td>
              <div class="btn-group btn-group-sm" role="group">
                <a href="<?= base_url('touragencies/edit/'.$agency['id']) ?>" class="btn btn-warning" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <button type="button" class="btn btn-danger" onclick="deleteItem('<?= $agency['id'] ?>', 'touragencies', '<?= esc($agency['name']) ?>')" title="Delete">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<script>
const baseUrl = '<?= base_url() ?>';

function deleteItem(id, type, name) {
  Swal.fire({
    title: 'Delete Tour Agency?',
    text: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6b7280',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel',
    background: '#fff'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = baseUrl + type + '/delete/' + id;
    }
  });
}
</script>

<?= $this->endSection() ?>