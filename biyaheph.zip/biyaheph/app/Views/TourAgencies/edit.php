
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row">
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-3">Edit Tour Agency</h4>

        <form method="post" action="<?= base_url('touragencies/update/'.$agency['id']) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Name</label>
            <input class="form-control" type="text" name="name" required value="<?= esc($agency['name']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Contact Number</label>
            <input class="form-control" type="text" name="contact" required value="<?= esc($agency['contact']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required value="<?= esc($agency['email']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea class="form-control" name="address" rows="3"><?= esc($agency['address'] ?? '') ?></textarea>
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary btn-lg">
              <i class="fa fa-save me-1"></i> Update Tour Agency
            </button>
            <a href="<?= base_url('touragencies') ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>