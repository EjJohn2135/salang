
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<style>
  .header-section {
    background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
    color: white;
    padding: 2rem;
    border-radius: 1rem;
    margin-bottom: 2rem;
  }

  .header-section h2 {
    color: white;
    margin-bottom: 0.5rem;
  }

  .table thead th {
    background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);
    color: white;
    border: none;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
  }

  .table tbody tr:hover {
    background: #fff5f5;
  }

  .btn-group-sm .btn {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
  }

  .empty-state {
    text-align: center;
    padding: 3rem;
    background: linear-gradient(135deg, #ffe5e5 0%, #ffd9d9 100%);
    border-radius: 1rem;
    border: 2px dashed #ff6b6b;
  }
</style>

<div class="header-section">
  <div class="d-flex justify-content-between align-items-center">
    <div>
      <h2 class="mb-1">
        <i class="fas fa-map-pin me-2"></i>Tourist Spots
      </h2>
      <p class="mb-0" style="opacity: 0.95;">Manage tourist attractions and destinations</p>
    </div>
    <a href="<?= base_url('touristspots/create') ?>" class="btn btn-light btn-lg text-danger fw-bold">
      <i class="fas fa-plus me-1"></i> Add Tourist Spot
    </a>
  </div>
</div>

<?php if (session()->getFlashdata('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i> <?= session()->getFlashdata('success') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i> <?= session()->getFlashdata('error') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (empty($spots)): ?>
  <div class="empty-state">
    <i class="fas fa-map" style="font-size: 3rem; color: #ff6b6b; margin-bottom: 1rem;"></i>
    <h5 class="text-danger">No Tourist Spots Yet</h5>
    <p class="text-muted">Start by adding your first tourist spot</p>
    <a href="<?= base_url('touristspots/create') ?>" class="btn btn-danger mt-3">
      <i class="fas fa-plus me-1"></i> Add Tourist Spot
    </a>
  </div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr>
          <th width="25%">Name</th>
          <th width="20%">Location</th>
          <th width="45%">Description</th>
          <th width="10%">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($spots as $spot): ?>
          <tr>
            <td>
              <strong><?= esc($spot['name']) ?></strong>
            </td>
            <td>
              <i class="fas fa-location-dot me-1" style="color: #ff6b6b;"></i>
              <?= esc($spot['location']) ?>
            </td>
            <td>
              <small class="text-muted">
                <?= esc(strlen($spot['description']) > 60 ? substr($spot['description'], 0, 60) . '...' : $spot['description']) ?>
              </small>
            </td>
            <td>
              <div class="btn-group btn-group-sm" role="group">
                <a href="<?= base_url('touristspots/edit/'.$spot['id']) ?>" class="btn btn-warning" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <button type="button" class="btn btn-danger" onclick="deleteItem('<?= $spot['id'] ?>', 'touristspots', '<?= esc($spot['name']) ?>')" title="Delete">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<script>
const baseUrl = '<?= base_url() ?>';

function deleteItem(id, type, name) {
  Swal.fire({
    title: 'Delete Tourist Spot?',
    text: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6b7280',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel',
    background: '#fff'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = baseUrl + type + '/delete/' + id;
    }
  });
}
</script>

<?= $this->endSection() ?>