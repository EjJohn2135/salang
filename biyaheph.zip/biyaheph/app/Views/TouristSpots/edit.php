
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row">
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-3">Edit Tourist Spot</h4>

        <form method="post" action="<?= base_url('touristspots/update/'.$spot['id']) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Name</label>
            <input class="form-control" type="text" name="name" required value="<?= esc($spot['name']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Location</label>
            <input class="form-control" type="text" name="location" required value="<?= esc($spot['location']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" name="description" rows="4"><?= esc($spot['description'] ?? '') ?></textarea>
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary btn-lg">
              <i class="fa fa-save me-1"></i> Update Tourist Spot
            </button>
            <a href="<?= base_url('touristspots') ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>