
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>BiyahePH - Explore Philippines</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', 'Poppins', system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background-color: #f8fafc;
      color: #334155;
    }

    /* Navbar Styling */
    .navbar {
      background: linear-gradient(135deg, #0066cc 0%, #00a8e8 100%) !important;
      padding: 1rem 0 !important;
      box-shadow: 0 2px 10px rgba(0, 102, 204, 0.15);
      backdrop-filter: blur(10px);
    }

    .navbar-brand {
      font-family: 'Poppins', sans-serif;
      font-size: 1.5rem !important;
      font-weight: 700 !important;
      letter-spacing: -0.5px;
      background: linear-gradient(135deg, #ffffff 0%, #e0f2fe 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .navbar .nav-link {
      color: rgba(255, 255, 255, 0.9) !important;
      font-weight: 500;
      margin: 0 0.5rem;
      padding: 0.5rem 1rem !important;
      border-radius: 0.5rem;
      transition: all 0.3s ease;
      position: relative;
    }

    .navbar .nav-link:hover {
      color: #ffffff !important;
      background: rgba(255, 255, 255, 0.1);
      transform: translateY(-2px);
    }

    .navbar .nav-link::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 0;
      height: 2px;
      background: #ffffff;
      transition: width 0.3s ease;
    }

    .navbar .nav-link:hover::after {
      width: 100%;
    }

    /* Sidebar Styling */
    .sidebar {
      min-height: 100vh;
      background: linear-gradient(180deg, #0066cc 0%, #0052a3 100%);
      color: #fff;
      padding: 2rem 1rem !important;
      position: sticky;
      top: 0;
      box-shadow: 2px 0 20px rgba(0, 102, 204, 0.2);
      overflow-y: auto;
    }

    .sidebar .nav-link {
      color: rgba(255, 255, 255, 0.85);
      padding: 0.75rem 1rem !important;
      border-radius: 0.6rem;
      margin-bottom: 0.5rem;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      border-left: 3px solid transparent;
      display: flex;
      align-items: center;
      position: relative;
      overflow: hidden;
    }

    .sidebar .nav-link::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.1);
      transition: left 0.3s ease;
      z-index: -1;
    }

    .sidebar .nav-link:hover {
      color: #ffffff;
      background: rgba(255, 255, 255, 0.15);
      border-left-color: #00d4ff;
      transform: translateX(4px);
    }

    .sidebar .nav-link:hover::before {
      left: 0;
    }

    .sidebar .nav-link.active {
      background: rgba(255, 255, 255, 0.2);
      color: #ffffff;
      border-left-color: #00d4ff;
      box-shadow: inset 0 0 10px rgba(0, 212, 255, 0.2);
    }

    .sidebar .nav-link i {
      width: 20px;
      text-align: center;
      margin-right: 0.75rem;
      transition: all 0.3s ease;
    }

    .sidebar .nav-link:hover i {
      color: #00d4ff;
      transform: scale(1.1);
    }

    .sidebar-title {
      font-family: 'Poppins', sans-serif;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: rgba(255, 255, 255, 0.5);
      padding: 1.5rem 1rem 0.75rem;
      margin-top: 1.5rem;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    }

    .sidebar .collapse .nav-link {
      padding-left: 2rem !important;
      font-size: 0.95rem;
    }

    /* Collapse Toggle Animation */
    #setupToggleIcon {
      transition: transform 0.3s ease;
      color: #00d4ff;
    }

    /* Content Area */
    .content {
      padding-top: 2rem;
      padding-bottom: 2rem;
      background-color: #f8fafc;
      min-height: calc(100vh - 70px);
    }

    /* Scrollbar Styling */
    .sidebar::-webkit-scrollbar {
      width: 6px;
    }

    .sidebar::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.05);
    }

    .sidebar::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 3px;
    }

    .sidebar::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.3);
    }

    /* Responsive Design */
    @media (max-width: 991.98px) {
      .sidebar {
        position: fixed;
        left: -250px;
        width: 250px;
        height: 100vh;
        z-index: 1050;
        transition: left 0.3s ease;
      }

      .sidebar.show {
        left: 0;
      }

      .content {
        width: 100%;
      }
    }

    /* Alert/Toast Styling */
    .alert {
      border: none;
      border-radius: 0.8rem;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      border-left: 4px solid;
    }

    .alert-success {
      background: linear-gradient(135deg, #d1fae5 0%, #ecfdf5 100%);
      border-left-color: #10b981;
      color: #065f46;
    }

    .alert-danger {
      background: linear-gradient(135deg, #fee2e2 0%, #fef2f2 100%);
      border-left-color: #ef4444;
      color: #7f1d1d;
    }

    .alert-warning {
      background: linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%);
      border-left-color: #f59e0b;
      color: #78350f;
    }

    .alert-info {
      background: linear-gradient(135deg, #dbeafe 0%, #f0f9ff 100%);
      border-left-color: #0066cc;
      color: #082f49;
    }

    /* Button Styling */
    .btn {
      border: none;
      border-radius: 0.6rem;
      font-weight: 600;
      transition: all 0.3s ease;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    .btn-primary {
      background: linear-gradient(135deg, #0066cc 0%, #00a8e8 100%);
      color: #ffffff;
    }

    .btn-primary:hover {
      background: linear-gradient(135deg, #0052a3 0%, #0088cc 100%);
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(0, 102, 204, 0.3);
    }

    .btn-success {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: #ffffff;
    }

    .btn-success:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
    }

    .btn-danger {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      color: #ffffff;
    }

    .btn-danger:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(239, 68, 68, 0.3);
    }

    .btn-outline-primary {
      border: 2px solid #0066cc;
      color: #0066cc;
    }

    .btn-outline-primary:hover {
      background: #0066cc;
      color: #ffffff;
      transform: translateY(-2px);
    }

    /* Card Styling */
    .card {
      border: none;
      border-radius: 0.8rem;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
      transition: all 0.3s ease;
      background: #ffffff;
    }

    .card:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 30px rgba(0, 102, 204, 0.15);
    }

    /* Badge Styling */
    .badge {
      border-radius: 0.5rem;
      padding: 0.5rem 0.875rem;
      font-weight: 600;
      font-size: 0.85rem;
    }

    .badge-primary {
      background: linear-gradient(135deg, #0066cc 0%, #00a8e8 100%);
    }

    .badge-success {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    }

    .badge-danger {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    }

    /* Table Styling */
    .table {
      border-collapse: separate;
      border-spacing: 0;
    }

    .table thead th {
      background: linear-gradient(135deg, #0066cc 0%, #00a8e8 100%);
      color: #ffffff;
      border: none;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.85rem;
      letter-spacing: 0.5px;
      padding: 1rem;
    }

    .table tbody tr {
      transition: all 0.3s ease;
      border-bottom: 1px solid #e2e8f0;
    }

    .table tbody tr:hover {
      background: #f0f9ff;
      box-shadow: inset 0 0 10px rgba(0, 102, 204, 0.05);
    }

    .table tbody td {
      padding: 1rem;
      vertical-align: middle;
    }

    /* Form Styling */
    .form-control, .form-select {
      border: 1.5px solid #e2e8f0;
      border-radius: 0.6rem;
      padding: 0.75rem 1rem;
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
      border-color: #0066cc;
      box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
    }

    .form-label {
      font-weight: 600;
      color: #334155;
      margin-bottom: 0.5rem;
    }

    /* Typography */
    h1, h2, h3, h4, h5, h6 {
      font-family: 'Poppins', sans-serif;
      font-weight: 700;
      color: #1e293b;
    }

    /* Divider */
    .divider {
      height: 1px;
      background: linear-gradient(90deg, transparent, #e2e8f0, transparent);
      margin: 2rem 0;
    }

    /* Loading Animation */
    .spinner-border {
      color: #0066cc;
      border-top-color: #00a8e8;
    }

    /* Smooth Transitions */
    a, button, input, select, textarea {
      transition: all 0.3s ease;
    }

    /* Print Styles */
    @media print {
      .navbar, .sidebar {
        display: none;
      }
      
      .content {
        padding: 0;
      }
    }
  </style>
</head>

<body>
  <!-- Top Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?= base_url() ?>">
        <i class="fas fa-compass me-2"></i>BiyahePH
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <?php if (session()->get('logged_in')): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('dashboard') ?>">
                <i class="fas fa-home me-1"></i>Dashboard
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('auth/logout') ?>">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
              </a>
            </li>
          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('auth/login') ?>">
                <i class="fas fa-sign-in-alt me-1"></i>Login
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('auth/register') ?>">
                <i class="fas fa-user-plus me-1"></i>Register
              </a>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Container -->
  <div class="container-fluid">
    <div class="row g-0">
      <!-- Sidebar -->
      <aside class="col-lg-2 d-none d-lg-block sidebar">
        <ul class="nav flex-column">
          <?php if (session()->get('logged_in')): ?>
            <li class="mb-2">
              <a class="nav-link" href="<?= base_url('dashboard') ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
              </a>
            </li>
            <li class="mb-2">
              <a class="nav-link" href="<?= base_url('packages') ?>">
                <i class="fas fa-boxes-stacked"></i>
                <span>Packages</span>
              </a>
            </li>

            <?php if (session()->get('role') === 'admin'): ?>
              <!-- Admin Management Section -->
                <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('settings/maintenance') ?>">
                        <i class="fas fa-tools"></i>
                        <span>Maintenance Mode</span>
                      </a>
                    </li>
                    <li class="mb-2">
                <a class="nav-link" href="<?= base_url('admin/activity-logs') ?>">
                  <i class="fas fa-list"></i>
                  <span>Activity Logs</span>
                </a>
             </li>
              <div class="sidebar-title">Management</div>

              <li class="mb-2">
                <a class="nav-link" href="<?= base_url('packages/create') ?>">
                  <i class="fas fa-plus-circle"></i>
                  <span>Add Package</span>
                </a>
              </li>
              <li class="mb-2">
                <a class="nav-link" href="<?= base_url('bookings/manage') ?>">
                  <i class="fas fa-calendar-check"></i>
                  <span>Manage Bookings</span>
                </a>
              </li>

              <!-- Setup Configuration Dropdown -->
              <div class="sidebar-title">Configuration</div>

              <li class="nav-item">
                <a class="nav-link d-flex justify-content-between align-items-center" href="#setupMenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="setupMenu">
                  <span>
                    <i class="fas fa-cog"></i>
                    <span>Setup</span>
                  </span>
                  <i class="fas fa-chevron-down" id="setupToggleIcon"></i>
                </a>
                <div class="collapse" id="setupMenu">
                  <ul class="nav flex-column ps-3 mt-2">
                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('accommodations') ?>">
                        <i class="fas fa-hotel"></i>
                        <span>Accommodations</span>
                      </a>
                    </li>
                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('accommodations/create') ?>">
                        <i class="fas fa-plus"></i>
                        <span>Add Accommodation</span>
                      </a>
                    </li>

                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('touristspots') ?>">
                        <i class="fas fa-map-pin"></i>
                        <span>Tourist Spots</span>
                      </a>
                    </li>
                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('touristspots/create') ?>">
                        <i class="fas fa-plus"></i>
                        <span>Add Tourist Spot</span>
                      </a>
                    </li>

                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('touragencies') ?>">
                        <i class="fas fa-briefcase"></i>
                        <span>Tour Agencies</span>
                      </a>
                    </li>
                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('touragencies/create') ?>">
                        <i class="fas fa-plus"></i>
                        <span>Add Tour Agency</span>
                      </a>
                    </li>

                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('tourguides') ?>">
                        <i class="fas fa-user-tie"></i>
                        <span>Tour Guides</span>
                      </a>
                    </li>
                    <li class="mb-2">
                      <a class="nav-link" href="<?= base_url('tourguides/create') ?>">
                        <i class="fas fa-plus"></i>
                        <span>Add Tour Guide</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
            <?php else: ?>
              <!-- Tourist Section -->
              <div class="sidebar-title">Activities</div>
              <li class="mb-2">
                <a class="nav-link" href="<?= base_url('bookings/my-bookings') ?>">
                  <i class="fas fa-ticket-alt"></i>
                  <span>My Bookings</span>
                </a>
              </li>
            <?php endif; ?>
          <?php endif; ?>
        </ul>
      </aside>

      <!-- Main Content -->
      <main class="col-lg-10 content">
        <div class="container-fluid">
          <?= $this->renderSection('content') ?>
        </div>
      </main>
    </div>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="container my-4">
    <?php if (session()->getFlashdata('success')): ?>
      <div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
      <div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div>
    <?php endif; ?>

    <?= $this->renderSection('content') ?>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Setup Collapse Animation
      const setupToggle = document.getElementById('setupMenu');
      const setupIcon = document.getElementById('setupToggleIcon');

      if (setupToggle && setupIcon) {
        setupToggle.addEventListener('show.bs.collapse', function() {
          setupIcon.style.transform = 'rotate(180deg)';
        });

        setupToggle.addEventListener('hide.bs.collapse', function() {
          setupIcon.style.transform = 'rotate(0deg)';
        });
      }

      // Flash Messages
      <?php if (session()->getFlashdata('success')): ?>
        Swal.fire({
          icon: 'success',
          title: 'Success!',
          text: '<?= esc(session()->getFlashdata('success')) ?>',
          timer: 3500,
          timerProgressBar: true,
          showConfirmButton: false,
          background: '#fff',
          didOpen: (toast) => {
            toast.style.borderLeft = '4px solid #10b981';
          }
        });
      <?php endif; ?>

      <?php if (session()->getFlashdata('error')): ?>
        Swal.fire({
          icon: 'error',
          title: 'Oops!',
          text: '<?= esc(session()->getFlashdata('error')) ?>',
          timer: 4000,
          timerProgressBar: true,
          showConfirmButton: false,
          background: '#fff',
          didOpen: (toast) => {
            toast.style.borderLeft = '4px solid #ef4444';
          }
        });
      <?php endif; ?>
    });
  </script>
    <script>
    const BASE_URL = '<?= rtrim(base_url(), "/") ?>/';
    const SITE_URL = '<?= rtrim(site_url(), "/") ?>/';
  </script>
</body>

</html>