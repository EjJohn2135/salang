
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row">
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-3">Edit Tour Guide</h4>

        <form method="post" action="<?= base_url('tourguides/update/'.$guide['id']) ?>">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Name</label>
            <input class="form-control" type="text" name="name" required value="<?= esc($guide['name']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Email</label>
            <input class="form-control" type="email" name="email" required value="<?= esc($guide['email']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Phone</label>
            <input class="form-control" type="text" name="phone" required value="<?= esc($guide['phone']) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label">Expertise</label>
            <input class="form-control" type="text" name="expertise" placeholder="e.g. Mountain Climbing, History" value="<?= esc($guide['expertise'] ?? '') ?>">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary btn-lg">
              <i class="fa fa-save me-1"></i> Update Tour Guide
            </button>
            <a href="<?= base_url('tourguides') ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>