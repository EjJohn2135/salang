
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<style>
  .header-section {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
    padding: 2rem;
    border-radius: 1rem;
    margin-bottom: 2rem;
  }

  .header-section h2 {
    color: white;
    margin-bottom: 0.5rem;
  }

  .table thead th {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    color: white;
    border: none;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
  }

  .table tbody tr:hover {
    background: #fffbf0;
  }

  .btn-group-sm .btn {
    padding: 0.4rem 0.8rem;
    font-size: 0.85rem;
  }

  .empty-state {
    text-align: center;
    padding: 3rem;
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border-radius: 1rem;
    border: 2px dashed #f59e0b;
  }
</style>

<div class="header-section">
  <div class="d-flex justify-content-between align-items-center">
    <div>
      <h2 class="mb-1">
        <i class="fas fa-user-tie me-2"></i>Tour Guides
      </h2>
      <p class="mb-0" style="opacity: 0.95;">Manage professional tour guides</p>
    </div>
    <a href="<?= base_url('tourguides/create') ?>" class="btn btn-light btn-lg text-warning fw-bold">
      <i class="fas fa-plus me-1"></i> Add Tour Guide
    </a>
  </div>
</div>

<?php if (session()->getFlashdata('success')): ?>
  <div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i> <?= session()->getFlashdata('success') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i> <?= session()->getFlashdata('error') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  </div>
<?php endif; ?>

<?php if (empty($guides)): ?>
  <div class="empty-state">
    <i class="fas fa-users" style="font-size: 3rem; color: #f59e0b; margin-bottom: 1rem;"></i>
    <h5 class="text-warning">No Tour Guides Yet</h5>
    <p class="text-muted">Start by adding your first tour guide</p>
    <a href="<?= base_url('tourguides/create') ?>" class="btn btn-warning mt-3">
      <i class="fas fa-plus me-1"></i> Add Tour Guide
    </a>
  </div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr>
          <th width="25%">Name</th>
          <th width="25%">Email</th>
          <th width="15%">Phone</th>
          <th width="25%">Expertise</th>
          <th width="10%">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($guides as $guide): ?>
          <tr>
            <td>
              <strong><?= esc($guide['name']) ?></strong>
            </td>
            <td>
              <small>
                <i class="fas fa-envelope me-1" style="color: #f59e0b;"></i>
                <?= esc($guide['email']) ?>
              </small>
            </td>
            <td>
              <small>
                <i class="fas fa-phone me-1" style="color: #f59e0b;"></i>
                <?= esc($guide['contact'] ?? $guide['phone'] ?? 'N/A') ?>
              </small>
            </td>
            <td>
              <small class="text-muted">
                <?= esc($guide['expertise'] ?? '—') ?>
              </small>
            </td>
            <td>
              <div class="btn-group btn-group-sm" role="group">
                <a href="<?= base_url('tourguides/edit/'.$guide['id']) ?>" class="btn btn-warning" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <button type="button" class="btn btn-danger" onclick="deleteItem('<?= $guide['id'] ?>', 'tourguides', '<?= esc($guide['name']) ?>')" title="Delete">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<script>
const baseUrl = '<?= base_url() ?>';

function deleteItem(id, type, name) {
  Swal.fire({
    title: 'Delete Tour Guide?',
    text: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6b7280',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel',
    background: '#fff'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = baseUrl + type + '/delete/' + id;
    }
  });
}
</script>

<?= $this->endSection() ?>