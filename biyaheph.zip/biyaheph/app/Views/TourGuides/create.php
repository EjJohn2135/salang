
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row">
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title mb-4">
          <i class="fas fa-user-tie me-2" style="color: #f59e0b;"></i>Add New Tour Guide
        </h4>

        <form method="post" action="<?= base_url('tourguides/store') ?>" enctype="multipart/form-data">
          <?= csrf_field() ?>

          <!-- Photo Upload -->
          <div class="mb-4">
            <label class="form-label fw-bold">Photo <span class="text-danger">*</span></label>
            <div class="input-group">
              <input class="form-control" type="file" id="photo" name="photo" accept="image/*" required>
            </div>
            <small class="text-muted d-block mt-2">
              <i class="fas fa-info-circle me-1"></i>
              Accepted formats: JPG, PNG, GIF (Max: 2MB)
            </small>
            <!-- Image Preview -->
            <div id="photoPreview" class="mt-3" style="display: none;">
              <img id="previewImg" src="" alt="Preview" style="max-width: 200px; border-radius: 50%; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);">
            </div>
          </div>

          <hr class="divider">

          <div class="mb-3">
            <label class="form-label fw-bold">Name <span class="text-danger">*</span></label>
            <input class="form-control form-control-lg" type="text" name="name" placeholder="e.g. John Smith" required value="<?= esc(old('name')) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label fw-bold">Email <span class="text-danger">*</span></label>
            <input class="form-control form-control-lg" type="email" name="email" placeholder="e.g. john@example.com" required value="<?= esc(old('email')) ?>">
          </div>

          <div class="mb-3">
            <label class="form-label fw-bold">Contact Number <span class="text-danger">*</span></label>
            <input class="form-control form-control-lg" type="text" name="contact" placeholder="e.g. 09123456789" required value="<?= esc(old('contact')) ?>">
          </div>

          <div class="mb-4">
            <label class="form-label fw-bold">Expertise</label>
            <input class="form-control form-control-lg" type="text" name="expertise" placeholder="e.g. Mountain Climbing, History, Nature" value="<?= esc(old('expertise')) ?>">
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-success btn-lg">
              <i class="fas fa-save me-2"></i> Add Tour Guide
            </button>
            <a href="<?= base_url('tourguides') ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  const photoInput = document.getElementById('photo');
  const photoPreview = document.getElementById('photoPreview');
  const previewImg = document.getElementById('previewImg');

  photoInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(event) {
        previewImg.src = event.target.result;
        photoPreview.style.display = 'block';
      };
      reader.readAsDataURL(file);
    }
  });
</script>

<?= $this->endSection() ?>