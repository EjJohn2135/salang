<?php


namespace App\Controllers;

use App\Models\TourAgencyModel;

class TourAgencies extends BaseController
{
     public function __construct()
    {
        helper('text'); // Load text helper
    }
    public function index()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourAgencyModel();
        $data['agencies'] = $model->orderBy('created_at', 'DESC')->findAll();

        return view('touragencies/index', $data);
    }

    public function create()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        return view('touragencies/create');
    }

    public function store()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourAgencyModel();

        $data = [
            'name' => $this->request->getPost('name'),
            'contact' => $this->request->getPost('contact'),
            'email' => $this->request->getPost('email'),
            'address' => $this->request->getPost('address'),
        ];

        if ($model->insert($data)) {
            return redirect()->to(base_url('touragencies'))->with('success', 'Tour agency added successfully');
        }

        return redirect()->back()->withInput()->with('error', 'Failed to add tour agency');
    }

    public function edit($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourAgencyModel();
        $data['agency'] = $model->find($id);

        if (!$data['agency']) {
            return redirect()->to(base_url('touragencies'))->with('error', 'Tour agency not found');
        }

        return view('touragencies/edit', $data);
    }

    public function update($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourAgencyModel();

        if (!$model->find($id)) {
            return redirect()->back()->with('error', 'Tour agency not found');
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'contact' => $this->request->getPost('contact'),
            'email' => $this->request->getPost('email'),
            'address' => $this->request->getPost('address'),
        ];

        $model->update($id, $data);

        return redirect()->to(base_url('touragencies'))->with('success', 'Tour agency updated successfully');
    }

    public function delete($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourAgencyModel();

        if (!$model->find($id)) {
            return redirect()->back()->with('error', 'Tour agency not found');
        }

        $model->delete($id);

        return redirect()->to(base_url('touragencies'))->with('success', 'Tour agency deleted');
    }
}