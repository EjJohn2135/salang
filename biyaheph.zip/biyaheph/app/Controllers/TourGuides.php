<?php


namespace App\Controllers;

use App\Models\TourGuideModel;

class TourGuides extends BaseController
{
     public function __construct()
    {
        helper('text'); // Load text helper
    }
    public function index()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourGuideModel();
        $data['guides'] = $model->orderBy('created_at', 'DESC')->findAll();

        return view('tourguides/index', $data);
    }

    public function create()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        return view('tourguides/create');
    }

    public function store()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourGuideModel();

        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'expertise' => $this->request->getPost('expertise'),
        ];

        if ($model->insert($data)) {
            return redirect()->to(base_url('tourguides'))->with('success', 'Tour guide added successfully');
        }

        return redirect()->back()->withInput()->with('error', 'Failed to add tour guide');
    }

    public function edit($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourGuideModel();
        $data['guide'] = $model->find($id);

        if (!$data['guide']) {
            return redirect()->to(base_url('tourguides'))->with('error', 'Tour guide not found');
        }

        return view('tourguides/edit', $data);
    }

    public function update($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourGuideModel();

        if (!$model->find($id)) {
            return redirect()->back()->with('error', 'Tour guide not found');
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'expertise' => $this->request->getPost('expertise'),
        ];

        $model->update($id, $data);

        return redirect()->to(base_url('tourguides'))->with('success', 'Tour guide updated successfully');
    }

    public function delete($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TourGuideModel();

        if (!$model->find($id)) {
            return redirect()->back()->with('error', 'Tour guide not found');
        }

        $model->delete($id);

        return redirect()->to(base_url('tourguides'))->with('success', 'Tour guide deleted');
    }
}