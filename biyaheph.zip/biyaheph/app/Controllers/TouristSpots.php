<?php


namespace App\Controllers;

use App\Models\TouristSpotModel;

class TouristSpots extends BaseController
{
     public function __construct()
    {
        helper('text'); // Load text helper
    }
    public function index()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TouristSpotModel();
        $data['spots'] = $model->orderBy('created_at', 'DESC')->findAll();

        return view('touristspots/index', $data);
    }

    public function create()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        return view('touristspots/create');
    }

    public function store()
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TouristSpotModel();

        $data = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'location' => $this->request->getPost('location'),
        ];

        if ($model->insert($data)) {
            return redirect()->to(base_url('touristspots'))->with('success', 'Tourist spot added successfully');
        }

        return redirect()->back()->withInput()->with('error', 'Failed to add tourist spot');
    }

    public function edit($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TouristSpotModel();
        $data['spot'] = $model->find($id);

        if (!$data['spot']) {
            return redirect()->to(base_url('touristspots'))->with('error', 'Tourist spot not found');
        }

        return view('touristspots/edit', $data);
    }

    public function update($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TouristSpotModel();

        if (!$model->find($id)) {
            return redirect()->back()->with('error', 'Tourist spot not found');
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'location' => $this->request->getPost('location'),
        ];

        $model->update($id, $data);

        return redirect()->to(base_url('touristspots'))->with('success', 'Tourist spot updated successfully');
    }

    public function delete($id)
    {
        if (session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Access denied');
        }

        $model = new TouristSpotModel();

        if (!$model->find($id)) {
            return redirect()->back()->with('error', 'Tourist spot not found');
        }

        $model->delete($id);

        return redirect()->to(base_url('touristspots'))->with('success', 'Tourist spot deleted');
    }
}