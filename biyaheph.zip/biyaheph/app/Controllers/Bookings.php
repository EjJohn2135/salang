<?php


namespace App\Controllers;

use App\Models\BookingModel;
use App\Models\TourPackageModel;

class Bookings extends BaseController
{
    protected $helpers = ['activity', 'mac'];

    public function book($id)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login to book');
        }

        $packageModel = new TourPackageModel();
        $package = $packageModel->find($id);
        if (!$package) {
            activity_log('book_package_not_found', ['package_id' => $id, 'user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->to(site_url('packages'))->with('error','Package not found');
        }

        $data['package'] = $package;
        return view('bookings/book', $data);
    }

    public function store()
    {
        if ($this->request->getMethod() !== 'post') {
            return redirect()->back()->with('error','Invalid request method');
        }
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }

        $bookingModel = new BookingModel();
        $packageModel = new TourPackageModel();

        $packageId = $this->request->getPost('package_id');
        $package = $packageModel->find($packageId);
        if (!$package) {
            activity_log('create_booking_package_not_found', ['package_id' => $packageId, 'user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','Package not found');
        }

        $numberOfTourists = max(1, (int)$this->request->getPost('number_of_tourists'));
        $totalPrice = $numberOfTourists * ((float)($package['rate_per_tourist'] ?? $package['price'] ?? 0));

        $data = [
            'user_id' => session()->get('id'),
            'package_id' => $packageId,
            'number_of_tourists' => $numberOfTourists,
            'total_price' => $totalPrice,
            'contact_name' => $this->request->getPost('contact_name'),
            'contact_email' => $this->request->getPost('contact_email'),
            'contact_phone' => $this->request->getPost('contact_phone'),
            'special_requests' => $this->request->getPost('special_requests'),
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ];

        $bookingId = $bookingModel->insert($data);
        if ($bookingId) {
            activity_log('create_booking', [
                'booking_id' => $bookingId,
                'booking_ref' => 'BK-' . $bookingId,
                'package_name' => $package['title'],
                'package_id' => $packageId,
                'user_id' => session()->get('id'),
                'user_name' => session()->get('name'),
                'number_of_tourists' => $numberOfTourists,
                'total_price' => $totalPrice
            ]);
            return redirect()->to(site_url('dashboard/tourist'))->with('success','Booking submitted! Awaiting approval.');
        }

        activity_log('create_booking_failed', ['package_id' => $packageId, 'user_id' => session()->get('id'), 'reason' => 'insert_error']);
        return redirect()->back()->withInput()->with('error','Failed to submit booking');
    }

    public function create()
    {
        if ($this->request->getMethod() !== 'post') {
            return redirect()->back()->with('error','Invalid request method.');
        }
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login to book.');
        }

        $packageId = $this->request->getPost('package_id');
        if (empty($packageId)) {
            activity_log('create_booking_no_package', ['user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','No package selected.');
        }

        $packageModel = new TourPackageModel();
        $package = $packageModel->find($packageId);
        if (!$package) {
            activity_log('create_booking_package_not_found', ['package_id' => $packageId, 'user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','Package not found.');
        }

        $bookingModel = new BookingModel();
        $rate = (float) ($package['rate_per_tourist'] ?? $package['price'] ?? 0);
        $data = [
            'user_id' => session()->get('id'),
            'package_id' => $packageId,
            'number_of_tourists' => 1,
            'total_price' => $rate,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ];

        $bookingId = $bookingModel->insert($data);
        if ($bookingId) {
            activity_log('create_booking', [
                'booking_id' => $bookingId,
                'booking_ref' => 'BK-' . $bookingId,
                'package_name' => $package['title'],
                'package_id' => $packageId,
                'user_id' => session()->get('id'),
                'user_name' => session()->get('name'),
                'number_of_tourists' => 1,
                'total_price' => $rate
            ]);
            return redirect()->to(site_url('dashboard/tourist'))->with('success','Booking created successfully.');
        }

        activity_log('create_booking_failed', ['package_id' => $packageId, 'user_id' => session()->get('id'), 'reason' => 'insert_error']);
        return redirect()->back()->with('error','Failed to create booking.');
    }

    public function myBookings()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }
        if (session()->get('role') !== 'tourist') {
            return redirect()->to(site_url('dashboard'))->with('error','Access denied');
        }

        $bookingModel = new BookingModel();
        $userId = session()->get('id');

        $bookings = $bookingModel
            ->select('bookings.*, tour_packages.title, tour_packages.image')
            ->join('tour_packages', 'tour_packages.id = bookings.package_id')
            ->where('bookings.user_id', $userId)
            ->orderBy('bookings.created_at', 'DESC')
            ->findAll();

        return view('bookings/my-bookings', ['bookings' => $bookings]);
    }

    public function manage()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }
        if (session()->get('role') !== 'admin') {
            return redirect()->to(site_url('dashboard'))->with('error','Access denied');
        }

        $bookingModel = new BookingModel();
        $status = $this->request->getGet('status');

        $query = $bookingModel
            ->select('bookings.*, tour_packages.title as package_title, users.name as user_name, users.email as user_email')
            ->join('tour_packages', 'tour_packages.id = bookings.package_id')
            ->join('users', 'users.id = bookings.user_id');

        if (!empty($status)) {
            $query->where('bookings.status', $status);
        }

        $bookings = $query->orderBy('bookings.created_at', 'DESC')->findAll();

        return view('bookings/manage', [
            'bookings' => $bookings,
            'currentStatus' => $status
        ]);
    }

    public function approve($bookingId)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }
        if (session()->get('role') !== 'admin') {
            activity_log('approve_booking_denied', ['booking_id' => $bookingId, 'reason' => 'unauthorized']);
            return redirect()->to(site_url('dashboard'))->with('error','Access denied');
        }

        $bookingModel = new BookingModel();
        $booking = $bookingModel->find($bookingId);

        if (!$booking) {
            activity_log('approve_booking_not_found', ['booking_id' => $bookingId, 'user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','Booking not found');
        }

        $bookingModel->update($bookingId, [
            'status' => 'approved',
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        activity_log('approve_booking', [
            'booking_id' => $bookingId,
            'booking_ref' => 'BK-' . $bookingId,
            'approved_by' => session()->get('id'),
            'approved_by_name' => session()->get('name'),
            'total_price' => $booking['total_price']
        ]);

        return redirect()->to(site_url('bookings/manage'))->with('success','Booking approved');
    }

    public function reject($bookingId)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }
        if (session()->get('role') !== 'admin') {
            activity_log('reject_booking_denied', ['booking_id' => $bookingId, 'reason' => 'unauthorized']);
            return redirect()->to(site_url('dashboard'))->with('error','Access denied');
        }

        $bookingModel = new BookingModel();
        $booking = $bookingModel->find($bookingId);

        if (!$booking) {
            activity_log('reject_booking_not_found', ['booking_id' => $bookingId, 'user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','Booking not found');
        }

        $bookingModel->update($bookingId, [
            'status' => 'rejected',
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        activity_log('reject_booking', [
            'booking_id' => $bookingId,
            'booking_ref' => 'BK-' . $bookingId,
            'rejected_by' => session()->get('id'),
            'rejected_by_name' => session()->get('name')
        ]);

        return redirect()->to(site_url('bookings/manage'))->with('success','Booking rejected');
    }

    public function cancel($bookingId = null)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }

        if (empty($bookingId)) {
            return redirect()->back()->with('error','Invalid booking id');
        }

        $bookingModel = new BookingModel();
        $booking = $bookingModel->find($bookingId);

        if (!$booking) {
            activity_log('cancel_booking_not_found', ['booking_id' => $bookingId, 'user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','Booking not found');
        }

        $userId = session()->get('id');
        $role = session()->get('role');

        if ($role !== 'admin' && $booking['user_id'] != $userId) {
            activity_log('cancel_booking_denied', ['booking_id' => $bookingId, 'reason' => 'unauthorized']);
            return redirect()->back()->with('error','Access denied');
        }

        if ($booking['status'] === 'approved') {
            activity_log('cancel_booking_not_allowed', ['booking_id' => $bookingId, 'reason' => 'already_approved']);
            return redirect()->back()->with('error','Cannot cancel approved bookings');
        }

        $bookingModel->update($bookingId, [
            'status' => 'cancelled',
            'updated_at' => date('Y-m-d H:i:s')
        ]);

        activity_log('cancel_booking', [
            'booking_id' => $bookingId,
            'booking_ref' => 'BK-' . $bookingId,
            'user_id' => session()->get('id'),
            'user_name' => session()->get('name'),
            'cancelled_by_role' => $role
        ]);

        if ($role === 'admin') {
            return redirect()->to(site_url('bookings/manage'))->with('success','Booking cancelled');
        }
        return redirect()->to(site_url('bookings/my-bookings'))->with('success','Booking cancelled');
    }

    public function exportCSV()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to(site_url('auth/login'))->with('error','Please login');
        }

        if (session()->get('role') !== 'admin') {
            activity_log('export_bookings_denied', ['reason' => 'unauthorized']);
            return redirect()->to(site_url('dashboard'))->with('error','Access denied');
        }

        $bookingModel = new BookingModel();

        $bookings = $bookingModel
            ->select('bookings.*, tour_packages.title as package_title, users.name as user_name, users.email as user_email')
            ->join('tour_packages', 'tour_packages.id = bookings.package_id')
            ->join('users', 'users.id = bookings.user_id')
            ->where('bookings.status', 'approved')
            ->orderBy('bookings.created_at', 'DESC')
            ->findAll();

        if (empty($bookings)) {
            activity_log('export_bookings_no_data', ['user_id' => session()->get('id'), 'user_name' => session()->get('name')]);
            return redirect()->back()->with('error','No approved bookings to export');
        }

        activity_log('export_bookings', [
            'user_id' => session()->get('id'),
            'user_name' => session()->get('name'),
            'count' => count($bookings),
            'timestamp' => date('Y-m-d H:i:s')
        ]);

        $filename = 'approved-bookings-' . date('Y-m-d-His') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

        fputcsv($output, [
            'Booking ID',
            'Customer Name',
            'Customer Email',
            'Package Title',
            'Number of Tourists',
            'Total Price',
            'Contact Name',
            'Contact Email',
            'Contact Phone',
            'Special Requests',
            'Status',
            'Booked Date'
        ]);

        foreach ($bookings as $booking) {
            fputcsv($output, [
                $booking['id'],
                $booking['user_name'] ?? '-',
                $booking['user_email'] ?? '-',
                $booking['package_title'] ?? '-',
                $booking['number_of_tourists'] ?? '-',
                number_format((float)($booking['total_price'] ?? 0), 2),
                $booking['contact_name'] ?? '-',
                $booking['contact_email'] ?? '-',
                $booking['contact_phone'] ?? '-',
                $booking['special_requests'] ?? '-',
                ucfirst($booking['status']),
                date('M d, Y', strtotime($booking['created_at']))
            ]);
        }

        fclose($output);
        exit;
    }
}