
<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->setAutoRoute(false);

// Home / Landing
$routes->get('/', 'Home::index');
$routes->get('home', 'Home::index');

// Auth group
$routes->group('auth', function($routes) {
    $routes->get('', 'Auth::login');
    $routes->get('login', 'Auth::login');
    $routes->post('loginPost', 'Auth::loginPost');
    $routes->get('register', 'Auth::register');
    $routes->post('registerPost', 'Auth::registerPost');
    $routes->get('approveAdmin/(:num)', 'Auth::approveAdmin/$1', ['filter' => 'authGuard']);
    $routes->get('rejectAdmin/(:num)', 'Auth::rejectAdmin/$1', ['filter' => 'authGuard']);
    $routes->get('logout', 'Auth::logout');
    $routes->get('verify/(:any)', 'Auth::verifyEmail/$1');
});

// Dashboard
$routes->group('dashboard', ['filter' => 'authGuard'], function($routes) {
    $routes->get('', 'Dashboard::index');
    $routes->get('tourist', 'Dashboard::tourist');
    $routes->get('admin', 'Dashboard::admin');
});

// Accommodations (Admin Only)
$routes->group('accommodations', ['filter' => 'adminGuard'], function($routes) {
    $routes->get('', 'Accommodations::index');
    $routes->get('create', 'Accommodations::create');
    $routes->post('store', 'Accommodations::store');
    $routes->get('edit/(:num)', 'Accommodations::edit/$1');
    $routes->post('update/(:num)', 'Accommodations::update/$1');
    $routes->get('delete/(:num)', 'Accommodations::delete/$1');
});

// Tourist Spots (Admin Only)
$routes->group('touristspots', ['filter' => 'adminGuard'], function($routes) {
    $routes->get('', 'TouristSpots::index');
    $routes->get('create', 'TouristSpots::create');
    $routes->post('store', 'TouristSpots::store');
    $routes->get('edit/(:num)', 'TouristSpots::edit/$1');
    $routes->post('update/(:num)', 'TouristSpots::update/$1');
    $routes->get('delete/(:num)', 'TouristSpots::delete/$1');
});

// Tour Agencies (Admin Only)
$routes->group('touragencies', ['filter' => 'adminGuard'], function($routes) {
    $routes->get('', 'TourAgencies::index');
    $routes->get('create', 'TourAgencies::create');
    $routes->post('store', 'TourAgencies::store');
    $routes->get('edit/(:num)', 'TourAgencies::edit/$1');
    $routes->post('update/(:num)', 'TourAgencies::update/$1');
    $routes->get('delete/(:num)', 'TourAgencies::delete/$1');
});

// Tour Guides (Admin Only)
$routes->group('tourguides', ['filter' => 'adminGuard'], function($routes) {
    $routes->get('', 'TourGuides::index');
    $routes->get('create', 'TourGuides::create');
    $routes->post('store', 'TourGuides::store');
    $routes->get('edit/(:num)', 'TourGuides::edit/$1');
    $routes->post('update/(:num)', 'TourGuides::update/$1');
    $routes->get('delete/(:num)', 'TourGuides::delete/$1');
});

// Packages (accessible to logged users; admin actions guarded)
$routes->group('packages', function($routes) {
    $routes->get('', 'Packages::index');
    $routes->get('create', 'Packages::create', ['filter' => 'adminGuard']);
    $routes->post('store', 'Packages::store', ['filter' => 'adminGuard']);
    $routes->get('edit/(:num)', 'Packages::edit/$1', ['filter' => 'adminGuard']);
    $routes->post('update/(:num)', 'Packages::update/$1', ['filter' => 'adminGuard']);
    $routes->get('delete/(:num)', 'Packages::delete/$1', ['filter' => 'adminGuard']);
    $routes->get('(:num)', 'Packages::show/$1'); // view single package
});

// Bookings
$routes->group('bookings', function($routes) {
    $routes->get('book/(:num)', 'Bookings::book/$1', ['filter' => 'authGuard']);
    // create booking via POST (used by JS submit on dashboard/tourist)
    $routes->post('create', 'Bookings::create', ['filter' => 'authGuard']);
    // legacy store (if needed)
    $routes->post('store', 'Bookings::store', ['filter' => 'authGuard']);
    $routes->get('my-bookings', 'Bookings::myBookings', ['filter' => 'authGuard']);
    $routes->get('manage', 'Bookings::manage', ['filter' => 'adminGuard']);
    $routes->get('approve/(:num)', 'Bookings::approve/$1', ['filter' => 'adminGuard']);
    $routes->get('reject/(:num)', 'Bookings::reject/$1', ['filter' => 'adminGuard']);
    $routes->get('cancel/(:num)', 'Bookings::cancel/$1', ['filter' => 'authGuard']);
     $routes->get('exportCSV', 'Bookings::exportCSV', ['filter' => 'adminGuard']);
});
$routes->group('settings', static function($routes) {
    $routes->get('maintenance', 'Settings::maintenanceSettings', ['filter' => 'adminGuard']);
    $routes->post('maintenance', 'Settings::maintenanceSettings', ['filter' => 'adminGuard']);
    $routes->post('toggle-maintenance', 'Settings::toggleMaintenance', ['filter' => 'adminGuard']);
});
$routes->group('', static function($routes) {
    // admin-only activity logs
    $routes->get('admin/activity-logs', 'ActivityLogs::index');
});
// Payments
$routes->group('payments', ['filter' => 'authGuard'], function($routes) {
    $routes->get('checkout', 'Payments::checkout');
    $routes->post('createSession', 'Payments::createSession');
    $routes->get('success', 'Payments::success');
    $routes->get('cancel', 'Payments::cancel');
});

// Profile
$routes->group('profile', ['filter' => 'authGuard'], function($routes) {
    $routes->get('', 'Profile::index');
    $routes->post('update', 'Profile::update');
});

// API / AJAX (examples)
$routes->group('api', function($routes) {
    // add API controllers/namespaces if implemented
    // $routes->post('packages/search', 'Api\Packages::search');
});
$routes->post('admin/maintenance/toggle', 'Maintenance::toggle', ['filter' => 'auth']);
$routes->post('admin/maintenance/enable', 'Maintenance::enable', ['filter' => 'auth']);
$routes->post('admin/maintenance/disable', 'Maintenance::disable', ['filter' => 'auth']);
$routes->get('admin/maintenance/status', 'Maintenance::status');

// 404 override
$routes->set404Override(function() {
    echo view('errors/custom_404');
});
$routes->group('admin', ['filter' => 'auth'], static function($routes) {
    $routes->get('dashboard', 'Admin::dashboard');
    $routes->get('monitor-ip', 'Admin::monitorIp');
    $routes->post('block-ip', 'Admin::blockIp');
    $routes->post('unblock-ip', 'Admin::unblockIp');
    $routes->get('ip-details/(:any)', 'Admin::ipDetails/$1');
    
    // ... existing admin routes
});